(function(){
  // Joystick com cálculo em PX e bloqueio de scroll
  window.BLGAME_Joystick = class {
    constructor(rootEl){
      this.root = rootEl;
      this.knob = document.createElement('div');
      this.knob.className = 'knob';
      this.root.appendChild(this.knob);

      this.rect = null;
      this.center = {x:0,y:0};
      this.active = false;
      this.dx = 0; this.dy = 0;

      this._onStart = this._onStart.bind(this);
      this._onMove  = this._onMove.bind(this);
      this._onEnd   = this._onEnd.bind(this);

      this.root.addEventListener('pointerdown', this._onStart, {passive:false});
      window.addEventListener('pointermove', this._onMove, {passive:false});
      window.addEventListener('pointerup', this._onEnd, {passive:false});
      window.addEventListener('pointercancel', this._onEnd, {passive:false});
    }

    _onStart(ev){
      ev.preventDefault();
      this.rect = this.root.getBoundingClientRect();
      this.center = { x: this.rect.width/2, y: this.rect.height/2 };
      this.active = true;
      try { this.root.setPointerCapture(ev.pointerId); } catch(e){}

      this._onMove(ev);
    }

    _onMove(ev){
      if(!this.active) return;
      ev.preventDefault();

      // Coords relativas ao root
      const x = (ev.clientX - this.rect.left);
      const y = (ev.clientY - this.rect.top);

      const dx = x - this.center.x;
      const dy = y - this.center.y;

      const maxR = (this.rect.width/2) - 6; // margem
      const len = Math.hypot(dx,dy) || 1;
      const clampedLen = Math.min(len, maxR);
      const nx = dx / len, ny = dy / len;

      // Posição visual do knob
      const knobX = this.center.x + nx * clampedLen;
      const knobY = this.center.y + ny * clampedLen;
      this.knob.style.left = knobX + 'px';
      this.knob.style.top  = knobY + 'px';

      // Saída normalizada
      this.dx = (dx / maxR);
      this.dy = (dy / maxR);
      const l2 = Math.hypot(this.dx, this.dy);
      if (l2 > 1) { this.dx/=l2; this.dy/=l2; }
    }

    _onEnd(ev){
      if (ev) ev.preventDefault();
      this.active = false;
      // reset
      this.knob.style.left = '50%';
      this.knob.style.top  = '50%';
      this.dx = 0; this.dy = 0;
    }

    getVector(){ return { dx: this.dx, dy: this.dy }; }
  }
})();
