(function () {
  const BLAPP = window.BLGAME_APP;
  const S     = window.BLGAME_STATE;

  const { $, delay, LOG, WARN, ERR, setText, mmss } = BLAPP.utils;
  const { ensurePortalAndMount, buildRootMarkup }    = BLAPP.dom;

  // >>> importa TAMBÉM as funções de sync/phase/onGoal/reset
  const {
    start3DPipelineOnce,
    sync3D,
    onPhase3D,
    reset3D,
    onGoal,
    set3DTargets,
    onEnded
  } = BLAPP.start3D;

  const { initDesktopControls, initMobileControls, startInputLoop, stopInputLoop } = BLAPP.input;
  const { startRenderLoop2D }                        = BLAPP.fx2d;
  const api                                          = BLAPP.api;

  // ====== Fases / HUD ======
  function showPhase(p, els) {
    S.mode = p;
    const all = [els.ovIdle, els.ovQueue, els.ovConn, els.ovCtd, els.ovHud, els.ovCtrlDesktop, els.ovCtrlMobile, els.ovEnded];
    all.forEach((el) => el && el.classList.add("blgame-hidden"));

    if (p === "idle")       els.ovIdle?.classList.remove("blgame-hidden");
    if (p === "queue")      els.ovQueue?.classList.remove("blgame-hidden");
    if (p === "connecting") els.ovConn?.classList.remove("blgame-hidden");
    if (p === "countdown")  els.ovCtd?.classList.remove("blgame-hidden");
    if (p === "playing") {
      els.ovHud?.classList.remove("blgame-hidden");
      (els.isTouch ? els.ovCtrlMobile : els.ovCtrlDesktop)?.classList.remove("blgame-hidden");
      if (els.specialIconImg && S.myLoadout.defenseIcon) els.specialIconImg.src = S.myLoadout.defenseIcon;
    }
    if (p === "ended") els.ovEnded?.classList.remove("blgame-hidden");

    if (els.isTouch) {
      const landscape = window.matchMedia("(orientation: landscape)").matches;
      els.orientationHint?.classList.toggle("blgame-hidden", landscape);
    }
    try { onPhase3D && onPhase3D(p); } catch(e){}
    LOG("phase ->", p);
  }

  // ====== Fila ======
  async function enterQueue(els) {
    const setResp = await api("set");
    LOG("set", setResp);

    if (!setResp.ok) {
      alert("Selecione ataque e defesa antes de jogar.");
      showPhase("idle", els);
      return;
    }

    S.myLoadout.defenseKey  = setResp.set?.defesa?.key || null;
    S.myLoadout.defenseIcon = setResp.set?.defesa?.icone_url || null;
    if (els.specialIconImg && S.myLoadout.defenseIcon) els.specialIconImg.src = S.myLoadout.defenseIcon;

    const joinResp = await api("queue/join", { method: "POST", body: JSON.stringify({}) });
    LOG("queue/join", joinResp);

    if (!joinResp.ok || !joinResp.ticketId) {
      alert("Falha ao entrar na fila.");
      showPhase("idle", els);
      return;
    }
    S.ticketId = joinResp.ticketId;
    S.queueStartTs = Date.now();
    showPhase("queue", els);
    tickQueueTimer(els);
    pollStatus(els);
  }

  async function pollStatus(els) {
    while (S.mode === "queue" && S.ticketId) {
      const st = await api("queue/status?ticketId=" + encodeURIComponent(S.ticketId));
      LOG("queue/status", st);
      if (st.ok && st.data?.status === "matched" && st.data.match) {
        await connectWS(st.data.match, els);
        return;
      }
      await delay(700);
    }
  }

  // ====== WS / SALA ======
  async function connectWS(match, els) {
    showPhase("connecting", els);
    try {
      const client = new Colyseus.Client(BLGAME.wsUrl);
      S.room = await client.join("soque", { joinCode: match.joinCode });
      LOG("WS conectado", { roomId: S.room.roomId, joinCode: match.joinCode });

      S.room.onError((code, message) => {
        ERR("room.onError", code, message);
        alert("Falha na conexão com a sala (" + code + ").");
        showPhase("idle", els);
        reset3D && reset3D();
      });
      S.room.onLeave((code) => {
        LOG("room.onLeave", code);
        if (S.mode !== "ended") { setText(els.endedTitle, "Conexão perdida"); showPhase("ended", els); }
        stopInputLoop();
      });

      S.room.onMessage("countdown", (msg) => runCountdown(msg?.ms || 2000, els));
      S.room.onMessage("goal", (msg) => {
        if (msg?.score) {
          setText(els.scoreA, String(msg.score.a || 0));
          setText(els.scoreB, String(msg.score.b || 0));
          try { onGoal && onGoal(); } catch(e){}
        }
      });
      S.room.onMessage("ended", (msg) => {
        setText(els.endedTitle, (msg?.reason === "opponent_left") ? "Oponente desconectou" : "Partida encerrada");
        showPhase("ended", els);
        stopInputLoop();
        try { onEnded && onEnded(S.stateRef); } catch(e){}
        try { S.room.leave(); } catch(e){}
      });

      S.room.onMessage("debug", (msg) => {
        if (msg?.type === "join_info") {
          if (!S.myLoadout.defenseKey && msg.defenseKey) S.myLoadout.defenseKey = msg.defenseKey;
        }
      });

      // >>> SINCRONIZAÇÃO 3D COM O ESTADO
      S.room.onStateChange((state) => {
        S.stateRef = state;

        if (state?.score) {
          setText(els.scoreA, String(state.score.a || 0));
          setText(els.scoreB, String(state.score.b || 0));
        }
        if (typeof state?.timeMs === "number") setText(els.matchTimerEl, mmss(state.timeMs));

        // envia estado para o módulo 3D (cria/atualiza atores)
        try { sync3D && sync3D(state, { myId: S.room.sessionId }); } catch(e){ WARN("sync3D error", e); }

        if (state?.phase === "playing" && S.mode !== "playing") {
          showPhase("playing", els);
          startInputLoop(els);
        }
      });

      await start3DPipelineOnce();   // 3D pronto
      startRenderLoop2D(els);        // FX 2D transparente

      // Safety: se countdown não chegar
      setTimeout(() => {
        if (S.mode === "connecting") { showPhase("playing", els); startInputLoop(els); }
      }, 2500);

      els.btnRequeue?.addEventListener("click", async () => {
        setText(els.scoreA, "0"); setText(els.scoreB, "0"); setText(els.matchTimerEl, "00:00");
        S.ticketId = null; try { reset3D && reset3D(); } catch(e){}
        try { S.room?.leave(); } catch(e){}
        S.room = null;
        await enterQueue(els);
      });
      els.btnExit?.addEventListener("click", () => {
        try { S.room?.leave(); } catch(e){}
        S.ticketId = null; S.room = null; showPhase("idle", els);
        try { reset3D && reset3D(); } catch(e){}
      });

    } catch (e) {
      ERR("WS connect error", e);
      alert("Falha na conexão com a sala.");
      showPhase("idle", els);
      try { reset3D && reset3D(); } catch(e){}
    }
  }

  function runCountdown(ms, els) {
    showPhase("countdown", els);
    let remain = ms;
    (function step() {
      if (S.mode !== "countdown") return;
      const s = Math.ceil(remain / 1000);
      setText(els.ctdNum, String(s));
      if (remain <= 0) { showPhase("playing", els); startInputLoop(els); return; }
      remain -= 100; setTimeout(step, 100);
    })();
  }

  // ===== Timer fila =====
  function tickQueueTimer(els){
    (function loop(){
      if (S.mode !== "queue") return;
      const ms = Date.now() - S.queueStartTs;
      setText(els.queueTimerEl, mmss(ms));
      requestAnimationFrame(loop);
    })();
  }

  // ===== Bootstrap =====
  async function bootstrap(){
    try{
      let root = document.querySelector(".blgame-root");
      if (!root) await delay(500); // dá tempo do shortcode renderizar
      root = document.querySelector(".blgame-root") || BLAPP.dom.buildRootMarkup();

      const portal = ensurePortalAndMount(root);

      const canvas = $(".blgame-canvas", root);
      let ctx = null;
      if (canvas) {
        try { ctx = canvas.getContext("2d"); }
        catch (e) { WARN("canvas.getContext falhou", e); }
      } else { LOG("Sem .blgame-canvas (ok: 3D puro)."); }

      const els = {
        root, portal,
        isTouch: ("ontouchstart" in window) || navigator.maxTouchPoints > 0,
        // overlays
        ovIdle: $('.blgame-overlay[data-phase="idle"]', root),
        ovQueue: $('.blgame-overlay[data-phase="queue"]', root),
        ovConn: $('.blgame-overlay[data-phase="connecting"]', root),
        ovCtd: $('.blgame-overlay[data-phase="countdown"]', root),
        ovHud: $('.blgame-overlay[data-phase="hud"]', root),
        ovCtrlDesktop: $('.blgame-overlay[data-phase="controls-desktop"]', root),
        ovCtrlMobile: $('.blgame-overlay[data-phase="controls-mobile"]', root),
        ovEnded: $('.blgame-overlay[data-phase="ended"]', root),
        // hud
        queueTimerEl: $('#blgame-queue-timer', root),
        scoreA: $('#blgame-score-a', root),
        scoreB: $('#blgame-score-b', root),
        matchTimerEl: $('#blgame-match-timer', root),
        ctdNum: $('#blgame-countdown-num', root),
        endedTitle: $('#blgame-ended-title', root),
        orientationHint: $('#blgame-orientation', root),
        specialIconImg: $('#blgame-special-icon', root),
        // buttons
        btnPlay: $('#blgame-btn-play', root),
        btnCancel: $('#blgame-btn-cancel', root),
        btnRequeue: $('#blgame-btn-requeue', root),
        btnExit: $('#blgame-btn-exit', root),
        // mobile controls
        joyEl: $('#blgame-joy', root), joy: null,
        btnAttack: $('#blgame-btn-attack', root),
        btnDefense: $('#blgame-btn-defense', root),
        // canvas
        canvas, ctx,
      };

      if (els.isTouch) initMobileControls(els); else initDesktopControls(els);

      els.btnPlay?.addEventListener("click", async ()=>{
        if (!BLGAME.isUserLoggedIn){ alert("Faça login para jogar."); return; }
        showPhase("connecting", els);
        await enterQueue(els);
      });
      els.btnCancel?.addEventListener("click", ()=>{ S.ticketId=null; showPhase("idle", els); });

      showPhase("idle", els);

      // define (só por garantia) o container/modelo p/ o 3D
      try {
        set3DTargets && set3DTargets({
          containerSelector: '#blgame-3d',
          modelUrl: ((BLGAME.models || (BLGAME.assets + 'models/')) + 'base-final.glb')
        });
      } catch(e){}

      // Carrega THREE e inicia 3D assim que possível (mesmo sem partida)
      await start3DPipelineOnce();
      // Liga FX 2D transparente
      startRenderLoop2D(els);

      LOG("boot ok | touch:", els.isTouch, "| canvas:", !!els.canvas);
    }catch(e){
      ERR("bootstrap failed", e);
    }
  }

  document.addEventListener("DOMContentLoaded", bootstrap);
})();
