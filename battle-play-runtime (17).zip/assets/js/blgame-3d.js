/* global THREE */
(function (global) {
  const BLAPP = global.BLGAME_APP;
  const S     = global.BLGAME_STATE;
  const CFG   = global.BLGAME || {};

  const { LOG, WARN, ERR } = BLAPP.utils;
  const { ensureThreeStack } = BLAPP.loader;
  const C = BLAPP.consts;

  const DEG = Math.PI / 180;

  // nomes dos clips no GLB
  const AnimNames = {
    turning:   'virando',
    idle:      'parado',
    possess:   'dominar-bola',
    defeat:    'derrota',
    run:       'correndo',
    celebrate: 'comemorar',
    shoot:     'chute',
    sprint:    'acelerando'
  };

  // ===== Estado interno 3D =====
  const S3D = {
    inited: false,
    domTarget: null,
    renderer: null,
    scene: null,
    camera: null,
    clock: null,
    template: null,
    mainArmatureName: null,
    mainMesh: null,
    baseBoneNames: null, // Set com nomes “base” dos ossos do esqueleto principal
    mixers: new Map(),
    actors: new Map(),
    ball: null,
    tmpCenter: new THREE.Vector3(),
    lastState: null,
    camBase: null,
    camTarget: null
  };

  // ===== Helpers =====
  function lerp(a,b,t){ return a+(b-a)*t; }
  function clamp(v,a,b){ return Math.max(a, Math.min(b,v)); }
  function escapeRe(str){ return str.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }

  // viewport ~mobile
  function isMobileViewport() {
    try {
      return (window.matchMedia && window.matchMedia('(max-width: 768px)').matches);
    } catch (e) {
      return (window.innerWidth || 0) <= 768;
    }
  }

  function baseCamConfig() {
    // valores pensados para enquadrar bem o campo e ficar estável
    if (isMobileViewport()) {
      return {
        y: 28,   // mais alto no mobile
        z: 24,
        xFactor: 0.04
      };
    }
    return {
      y: 24,    // desktop um pouco mais próximo
      z: 22,
      xFactor: 0.06
    };
  }

  // normaliza container que veio do app
  function normalizeContainer(target){
    // Aceita: Element, Node, jQuery/NodeList, {el}, selector string
    if (!target) return document.getElementById('blgame-3d') || document.body;

    // se veio como objeto { containerSelector, modelUrl }
    if (target.containerSelector && typeof target.containerSelector === 'string') {
      const el = document.querySelector(target.containerSelector);
      if (el) return el;
    }

    if (target instanceof Element) return target;
    if (target.nodeType === 1) return target;
    if (Array.isArray(target) || (typeof target.length === 'number' && target[0])) {
      if (target[0] && target[0].nodeType === 1) return target[0];
    }
    if (target.el && (target.el instanceof Element || target.el?.nodeType === 1)) return target.el;
    if (typeof target === 'string') return document.querySelector(target) || document.body;
    return document.getElementById('blgame-3d') || document.body;
  }

  function firstSkinnedMesh(root){
    let found=null;
    root.traverse(n=>{ if(!found && n.isSkinnedMesh) found=n; });
    return found;
  }

  function computeMainArmatureName(gltfScene){
    const skin = firstSkinnedMesh(gltfScene);
    if (!skin) return null;
    let p = skin;
    while (p && p.isBone) p = p.parent;
    while (p && p.parent && p.parent.isBone === false && p.parent !== gltfScene) p = p.parent;
    const name = (p && p.name) ? p.name : 'Armature';
    LOG('[3D] main armature =', name);
    return name;
  }

  // ===== Normalização de nomes de ossos / trilhas =====

  // "Armature/mixamorigHips_7" -> "mixamorigHips"
  function normalizeBoneBaseName(name){
    // remove prefixo de armature se houver
    let base = name;
    if (base.indexOf('/') !== -1) {
      const parts = base.split('/');
      base = parts[parts.length - 1];
    }
    // remove sufixos tipo `_7` ou `.001`
    base = base.replace(/(_\d+|\.\d{3})$/, '');
    return base;
  }

  function buildMainSkeletonBoneSet(){
    const mesh = firstSkinnedMesh(S3D.template.scene);
    if (!mesh || !mesh.skeleton || !Array.isArray(mesh.skeleton.bones)) {
      WARN('[3D] não encontrei SkinnedMesh principal para mapear esqueleto.');
      S3D.mainMesh = null;
      S3D.baseBoneNames = null;
      return;
    }
    S3D.mainMesh = mesh;
    const set = new Set();
    mesh.skeleton.bones.forEach(b => {
      if (!b || !b.name) return;
      const base = normalizeBoneBaseName(b.name);
      if (base) set.add(base);
    });
    S3D.baseBoneNames = set;
    LOG('[3D] main skeleton bone count =', set.size);
  }

  // Reescreve prefixo (caso trilhas venham com "Armature/Osso")
  function rewriteClipPrefix(clip, fromPrefix, toPrefix){
    const re = new RegExp('^' + escapeRe(fromPrefix) + '(?=/)');
    const tracks = clip.tracks.map(t => {
      const c = t.clone();
      c.name = t.name.replace(re, toPrefix);
      return c;
    });
    const out = new THREE.AnimationClip(clip.name, clip.duration, tracks);
    out.optimize();
    return out;
  }

  function guessClipPrefix(clip){
    const t = clip.tracks && clip.tracks[0];
    if (!t || !t.name) return null;
    const i = t.name.indexOf('/');
    return (i>0) ? t.name.slice(0,i) : null;
  }

  function mapClipToMainArmature(clip, mainPrefix){
    const pref = guessClipPrefix(clip);
    if (!pref || pref === mainPrefix) return clip;
    return rewriteClipPrefix(clip, pref, mainPrefix);
  }

  // Remapeia trilhas para usar os ossos do esqueleto principal
  function remapClipToMainSkeleton(clip){
    if (!S3D.baseBoneNames || !clip || !Array.isArray(clip.tracks)) return clip;

    const tracks = clip.tracks.map(t => {
      const c = t.clone();
      const dot = c.name.lastIndexOf('.');
      if (dot <= 0) return c;

      const nodeName = c.name.slice(0, dot);
      const prop     = c.name.slice(dot + 1); // position/quaternion/scale
      const baseName = normalizeBoneBaseName(nodeName);

      if (S3D.baseBoneNames.has(baseName)) {
        c.name = baseName + '.' + prop;
      }

      return c;
    });

    const out = new THREE.AnimationClip(clip.name, clip.duration, tracks);
    out.optimize();
    return out;
  }

  function countTracksBoundToMainSkeleton(clip){
    if (!clip || !Array.isArray(clip.tracks) || !S3D.baseBoneNames) {
      return { ok: 0, total: clip ? clip.tracks.length : 0 };
    }
    let ok = 0;
    clip.tracks.forEach(t => {
      const dot = t.name.lastIndexOf('.');
      if (dot <= 0) return;
      const nodeName = t.name.slice(0, dot);
      const baseName = normalizeBoneBaseName(nodeName);
      if (S3D.baseBoneNames.has(baseName)) ok++;
    });
    return { ok, total: clip.tracks.length };
  }

  // ===== Cena =====
  function makeScene(containerEl){
    const container = normalizeContainer(containerEl);
    if (!(container instanceof Element)) {
      WARN('[3D] container inválido, usando <body>');
    }
    LOG('[3D] targetEl ->', { tag: container.tagName, id: container.id });

    const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    renderer.outputEncoding = THREE.sRGBEncoding;

    // Garante um wrapper se o container for <body>
    if (container === document.body) {
      let mount = document.getElementById('blgame-3d-mount');
      if (!mount) {
        mount = document.createElement('div');
        mount.id = 'blgame-3d-mount';
        mount.style.position = 'absolute';
        mount.style.inset = '0';
        container.appendChild(mount);
      }
      mount.innerHTML = '';
      mount.appendChild(renderer.domElement);
    } else {
      container.innerHTML = '';
      container.appendChild(renderer.domElement);
    }

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0A0A0A);

    const camBase = baseCamConfig();
    const aspect = (container.clientWidth||window.innerWidth)/(container.clientHeight||window.innerHeight);

    const cam = new THREE.PerspectiveCamera(55, aspect, 0.1, 500);
    cam.position.set(0, camBase.y, camBase.z);
    cam.lookAt(0,0,0);

    S3D.camBase = camBase;
    S3D.camTarget = new THREE.Vector3(0, camBase.y, camBase.z);

    const hemi = new THREE.HemisphereLight(0xffffff, 0x202020, 0.9);
    scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xffffff, 0.9);
    dir.position.set(20,40,10);
    scene.add(dir);

    const field = new THREE.Mesh(
      new THREE.PlaneGeometry(C.FIELD_WIDTH, C.FIELD_HEIGHT, 1, 1),
      new THREE.MeshBasicMaterial({ color: 0x213744 })
    );
    field.rotation.x = -90*DEG;
    scene.add(field);

    const circle = new THREE.Mesh(
      new THREE.RingGeometry(2.9, 3.0, 64),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent:true, opacity:0.08, side: THREE.DoubleSide })
    );
    circle.rotation.x = -90*DEG;
    scene.add(circle);

    const ball = new THREE.Mesh(
      new THREE.SphereGeometry(C.BALL_RADIUS, 24, 16),
      new THREE.MeshStandardMaterial({ color: 0xdddddd, metalness:0.25, roughness:0.5 })
    );
    scene.add(ball);

    const clock = new THREE.Clock();

    S3D.renderer = renderer;
    S3D.scene = scene;
    S3D.camera = cam;
    S3D.clock = clock;
    S3D.ball = ball;

    function onResize(){
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      renderer.setSize(w, h, false);
      cam.aspect = w/h;
      cam.updateProjectionMatrix();

      // recalibra base da câmera para o novo viewport (mobile x desktop, portrait x landscape)
      const base = baseCamConfig();
      S3D.camBase = base;
      if (!S3D.camTarget) {
        S3D.camTarget = new THREE.Vector3(0, base.y, base.z);
      }
    }
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);

    function renderLoop(){
      requestAnimationFrame(renderLoop);
      const dt = clock.getDelta();
      S3D.mixers.forEach(m => m.update(dt));
      autoCamera(dt);
      const st = S3D.lastState || S.stateRef;
      if (st) updateActorsFromState(st);
      renderer.render(scene, cam);
    }
    renderLoop();
  }

  // câmera mais estável e “menos nervosa”
  function autoCamera(dt){
    if (!S3D.camera || !S3D.camBase) return;

    const base = S3D.camBase;

    let tx = 0;
    let ty = base.y;
    let tz = base.z;

    const players = Array.from(S3D.actors.values());
    if (players.length >= 1){
      const c = S3D.tmpCenter.set(0,0,0);
      players.forEach(a => c.add(a.root.position));
      c.multiplyScalar(1/players.length);

      let sep = 0;
      if (players.length === 2){
        sep = players[0].root.position.distanceTo(players[1].root.position);
      }

      // zoom MUITO leve baseado na distância entre os jogadores
      ty = base.y + clamp(sep * 0.15, 0, 3.5);
      tz = base.z + clamp(sep * 0.12, 0, 3.5);

      // deslocamento lateral bem sutil e limitado
      const maxOffsetX = 2.0;
      tx = clamp(c.x * (base.xFactor || 0.06), -maxOffsetX, maxOffsetX);
    }

    if (!S3D.camTarget) {
      S3D.camTarget = new THREE.Vector3(tx, ty, tz);
    } else {
      S3D.camTarget.set(tx, ty, tz);
    }

    const lerpFactor = Math.min(1, dt * 2.0); // suavização
    S3D.camera.position.lerp(S3D.camTarget, lerpFactor);
    S3D.camera.lookAt(0, 0, 0);
  }

  // ===== Modelo / Anim =====
  function loadGLB(url){
    return new Promise((resolve,reject)=>{
      const loader = new THREE.GLTFLoader();
      loader.load(url, gltf => resolve(gltf), undefined, reject);
    });
  }

  function ensureSpawnFromState(state){
    state.players.forEach((p, id)=>{
      if (!S3D.actors.has(id)){
        buildActorFromTemplate(id, p.team||0);
      }
    });
    Array.from(S3D.actors.keys()).forEach(id=>{
      if (!state.players.has(id)){
        const a = S3D.actors.get(id);
        if (a){
          S3D.scene.remove(a.root);
          S3D.mixers.delete(id);
        }
        S3D.actors.delete(id);
      }
    });
  }

  function faceVelocity(actor, vx, vy){
    const ang = Math.atan2(vx, vy);
    actor.root.rotation.y = ang;
  }

  function chooseAnimForSpeed(actor, speed){
    if (speed > 9.5 && actor.actions.sprint) return 'sprint';
    if (speed > 0.2 && actor.actions.run)    return 'run';
    return 'idle';
  }

  function playFade(actor, name, {fade=0.18, loop=true, once=false}={}){
    const actions = actor.actions;
    const next = actions[name];
    if (!next || actor.current === name) return;

    const now = actions[actor.current];
    if (now){ now.fadeOut(fade); now.enabled = true; }

    next.reset();
    next.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, once ? 1 : Infinity);
    next.clampWhenFinished = !!once;
    next.enabled = true;
    next.fadeIn(fade).play();
    actor.current = name;

    LOG('[3D] action ->', name);
  }

  function scaleActorToBallRatio(clone){
    const box = new THREE.Box3().setFromObject(clone);
    const h = Math.max(0.0001, box.max.y - box.min.y);
    const desiredH = (2 * C.BALL_RADIUS) * (C.PLAYER_TO_BALL_RATIO || 4.0);
    const s = desiredH / h;
    clone.scale.setScalar(s);
    LOG('[3D] scale', {height:h.toFixed(3), desired:desiredH.toFixed(3), scale:s.toFixed(3)});
  }

  function getActionsForClone(clone){
    const mixer = new THREE.AnimationMixer(clone);
    const actions = {};
    const clips = (S3D.template.animations || []);
    const mainPrefix = S3D.mainArmatureName || 'Armature';

    const MapAnim = {
      idle:      AnimNames.idle,
      run:       AnimNames.run,
      sprint:    AnimNames.sprint,
      turn:      AnimNames.turning,
      possess:   AnimNames.possess,
      shoot:     AnimNames.shoot,
      celebrate: AnimNames.celebrate,
      defeat:    AnimNames.defeat
    };

    Object.entries(MapAnim).forEach(([key, wantedName])=>{
      if (!wantedName) return;
      // procura por nome exato (lower) e depois por substring
      let clipRaw = clips.find(a => (a.name||'').toLowerCase() === wantedName);
      if (!clipRaw) {
        clipRaw = clips.find(a => (a.name||'').toLowerCase().indexOf(wantedName) !== -1);
      }
      if (!clipRaw) {
        WARN('[3D] clip não encontrado para', key, '(', wantedName, ')');
        return;
      }

      let clip = clipRaw;
      try {
        const pref = guessClipPrefix(clip);
        if (pref && pref !== mainPrefix) clip = mapClipToMainArmature(clip, mainPrefix);
        clip = remapClipToMainSkeleton(clip);
        const info = countTracksBoundToMainSkeleton(clip);
        LOG('[3D] clip', key, { src: clipRaw.name, map: `${info.ok}/${info.total} trilhas em ossos principais` });
      } catch (e) {
        WARN('[3D] erro ao mapear clip', key, e);
      }

      actions[key] = mixer.clipAction(clip);
    });

    return { mixer, actions };
  }

  function buildActorFromTemplate(playerId, team){
    const clone = THREE.SkeletonUtils.clone(S3D.template.scene);
    clone.traverse(n=>{ if (n.isMesh){ n.castShadow=false; n.receiveShadow=false; }});
    clone.position.set(0,0,0);

    const tint = team===0 ? new THREE.Color(0x64b5f6) : new THREE.Color(0xef9a9a);
    clone.traverse(n=>{
      if (n.isMesh && n.material){
        n.material = n.material.clone();
        n.material.color.lerp(tint, 0.12);
      }
    });

    scaleActorToBallRatio(clone);

    const { mixer, actions } = getActionsForClone(clone);
    if (actions.idle) actions.idle.play();

    S3D.scene.add(clone);
    S3D.mixers.set(playerId, mixer);
    S3D.actors.set(playerId, {
      root: clone,
      mixer,
      actions,
      current: 'idle',
      lastHasBall: false,
      lastPos: new THREE.Vector2(0,0),
      team
    });

    LOG('[3D] player-criado', {
      id: playerId,
      clips: Object.keys(actions)
    });
  }

  function updateActorsFromState(state){
    if (!S3D.template || !state || !state.players) return;

    ensureSpawnFromState(state);

    if (S3D.ball && state.ball) {
      S3D.ball.position.set(state.ball.x, C.BALL_RADIUS, state.ball.y);
    }

    state.players.forEach((p, id)=>{
      const a = S3D.actors.get(id);
      if (!a) return;
      a.root.position.set(p.x, 0, p.y);

      const speed = Math.hypot(p.vx, p.vy);
      faceVelocity(a, p.vx, p.vy);

      const animName = chooseAnimForSpeed(a, speed);
      if (animName !== a.current) playFade(a, animName);

      const nowHas = !!p.hasBall;
      if (nowHas && !a.lastHasBall && a.actions.possess){
        playFade(a, 'possess', {fade:0.08, once:true});
      }
      a.lastHasBall = nowHas;
    });
  }

  // ===== API principal =====
  async function start3DPipelineOnce(){
    if (S3D.inited) return;
    LOG('[3D] pipeline iniciado');

    await ensureThreeStack();

    const container = normalizeContainer(S3D.domTarget) || document.getElementById('blgame-3d') || document.body;
    makeScene(container);

    const url = (CFG.models || (CFG.assets + 'models/')) + 'base-final.glb';
    LOG('[3D] carregando GLB', url);
    S3D.template = await loadGLB(url);

    // mapear esqueleto principal e armature
    buildMainSkeletonBoneSet();
    S3D.mainArmatureName = computeMainArmatureName(S3D.template.scene);

    LOG('[3D] GLB carregado', {
      url,
      clips: (S3D.template.animations||[]).map(c=>c.name)
    });

    S3D.inited = true;
  }

  function set3DTargets(dom){
    S3D.domTarget = dom || null;
    LOG('[3D] set3DTargets', dom);
  }

  // sync vindo do app (opcional; usamos também S.stateRef)
  function syncState(state){
    if (!state) return;
    S.stateRef = state;
    S3D.lastState = state;
  }

  function goalFX(){ /* placeholder p/ fx futuros */ }

  function reset(){
    S3D.actors.forEach(a => S3D.scene.remove(a.root));
    S3D.actors.clear();
    S3D.mixers.clear();
    S3D.lastState = null;
  }

  // ===== Exports =====
  BLAPP.start3D = {
    start3DPipelineOnce,
    set3DTargets,
    // aliases esperados pelo blgame-app.js
    sync3D: syncState,
    onPhase3D: function(){},
    reset3D: reset,
    onGoal: goalFX,
    onEnded: function(){}
  };

  // Mantém também o namespace antigo, se algo usar
  BLAPP.G3D = { syncState, goalFX, reset };

})(window);
