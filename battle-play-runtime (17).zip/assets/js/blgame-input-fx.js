(function (global) {
  const BLAPP = global.BLGAME_APP;
  const S = global.BLGAME_STATE;
  const { LOG, WARN } = BLAPP.utils;
  const { DEF_MAGNET_RADIUS, FIELD_WIDTH, FIELD_HEIGHT } = BLAPP.consts;

  // ===== INPUT =====
  const keys = {};
  const input = { dx: 0, dy: 0, attack: false, defense: false };
  let inputTick = null;

  function initDesktopControls(els) {
    if (els.isTouch) return;
    window.addEventListener("keydown", (e) => { keys[e.code] = true; });
    window.addEventListener("keyup",   (e) => { keys[e.code] = false; });
  }

  function sampleDesktopAxes() {
    let x = 0, y = 0;
    if (keys["KeyA"] || keys["ArrowLeft"])  x -= 1;
    if (keys["KeyD"] || keys["ArrowRight"]) x += 1;
    if (keys["KeyW"] || keys["ArrowUp"])    y -= 1;
    if (keys["KeyS"] || keys["ArrowDown"])  y += 1;
    const len = Math.hypot(x, y) || 1; x/=len; y/=len;
    input.dx = x; input.dy = y;
    input.attack  = !!keys["KeyJ"];
    input.defense = !!keys["KeyK"];
  }

  function initMobileControls(els) {
    if (!els.isTouch) return;
    if (!els.joy) els.joy = new BLGAME_Joystick(els.joyEl);
    if (els.btnAttack) {
      els.btnAttack.addEventListener("pointerdown", () => input.attack = true);
      els.btnAttack.addEventListener("pointerup",   () => input.attack = false);
      els.btnAttack.addEventListener("pointercancel", () => input.attack = false);
    }
    if (els.btnDefense) {
      els.btnDefense.addEventListener("pointerdown", () => input.defense = true);
      els.btnDefense.addEventListener("pointerup",   () => input.defense = false);
      els.btnDefense.addEventListener("pointercancel", () => input.defense = false);
    }
    els.root.addEventListener("touchmove", (e)=>e.preventDefault(), {passive:false});
  }

  function startInputLoop(els) {
    stopInputLoop();
    inputTick = setInterval(() => {
      if (!S.room || (S.mode !== "playing" && S.mode !== "countdown")) return;
      if (els.isTouch && els.joy) { const v = els.joy.getVector(); input.dx = v.dx; input.dy = v.dy; }
      if (!els.isTouch) sampleDesktopAxes();
      S.room.send("input", { dx: input.dx, dy: input.dy, attack: input.attack, defense: input.defense });
    }, 66);
  }
  function stopInputLoop(){ if (inputTick){ clearInterval(inputTick); inputTick = null; } }

  // ===== FX 2D =====
  let raf2D = null, dpr = 1, lastW = 0, lastH = 0, animStart = performance.now();

  function resizeCanvasIfNeeded(els){
    if (!els.canvas) return;
    const wrap = els.canvas.parentElement;
    const cssW = wrap.clientWidth, cssH = wrap.clientHeight;
    const newDpr = Math.min(window.devicePixelRatio || 1, 2);
    const pxW = Math.floor(cssW*newDpr), pxH = Math.floor(cssH*newDpr);
    if (pxW!==lastW || pxH!==lastH || newDpr!==dpr){
      dpr = newDpr; lastW=pxW; lastH=pxH;
      els.canvas.width = pxW; els.canvas.height = pxH;
    }
  }
  function worldToScreen(els, x, y){
    if (!els.canvas) return [0,0,1];
    const sx = els.canvas.width / FIELD_WIDTH;
    const sy = els.canvas.height / FIELD_HEIGHT;
    return [els.canvas.width/2 + x*sx, els.canvas.height/2 + y*sy, Math.min(sx, sy)];
  }
  function drawBlackHoleFx(els, state){
    if (!els.ctx) return;
    const ctx = els.ctx;
    const t = (performance.now() - animStart)/1000;
    const dashOffset = -t*40;
    const pulse = 0.85 + 0.15*Math.sin(t*4);

    state.players.forEach((p) => {
      const isLocal = (S.room && S.room.sessionId === p.id);
      const active = p.defenseOn || (isLocal && input.defense);
      if (!active) return;
      const key = (typeof p.defenseKey === "string" ? p.defenseKey : "") || S.myLoadout?.defenseKey || "";
      if (key !== "buraco_negro") return;

      const [cx, cy, s] = worldToScreen(els, p.x, p.y);
      const R = DEF_MAGNET_RADIUS * s;

      ctx.save();
      const r0 = R*0.65*pulse, r1 = R*1.0*pulse;
      const grad = ctx.createRadialGradient(cx,cy,r0, cx,cy,r1);
      grad.addColorStop(0,"rgba(80,120,255,0.18)");
      grad.addColorStop(1,"rgba(80,120,255,0.02)");
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(cx,cy,r1,0,Math.PI*2); ctx.fill();

      ctx.strokeStyle = "rgba(120,170,255,0.8)";
      ctx.lineWidth = Math.max(1, 2*dpr);
      ctx.setLineDash([8*dpr, 8*dpr]); ctx.lineDashOffset = dashOffset;
      ctx.beginPath(); ctx.arc(cx,cy,R,0,Math.PI*2); ctx.stroke();

      ctx.globalAlpha = 0.45;
      const spokes = 12;
      for (let i=0;i<spokes;i++){
        const ang = (i/spokes)*Math.PI*2 + t*0.6;
        const ex = cx + Math.cos(ang)*R*0.95;
        const ey = cy + Math.sin(ang)*R*0.95;
        const ix = cx + Math.cos(ang)*R*0.62;
        const iy = cy + Math.sin(ang)*R*0.62;
        ctx.beginPath(); ctx.moveTo(ex,ey); ctx.lineTo(ix,iy); ctx.stroke();
      }
      ctx.restore();
    });
  }
  function render2D(els){
    if (!els.canvas) return;
    resizeCanvasIfNeeded(els);
    const ctx = els.ctx;
    ctx.clearRect(0,0,els.canvas.width, els.canvas.height);
    if (S.stateRef) drawBlackHoleFx(els, S.stateRef);
    raf2D = requestAnimationFrame(()=>render2D(els));
  }
  function startRenderLoop2D(els){
    if (raf2D) cancelAnimationFrame(raf2D);
    animStart = performance.now();
    raf2D = requestAnimationFrame(()=>render2D(els));
  }

  // ===== Exports =====
  BLAPP.input = { initDesktopControls, initMobileControls, startInputLoop, stopInputLoop, sampleDesktopAxes };
  BLAPP.fx2d  = { startRenderLoop2D };

})(window);
