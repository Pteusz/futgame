(function (global) {
  // ===== Namespace / Estado compartilhado =====
  global.BLGAME_STATE = {
    mode: "idle",              // idle|queue|connecting|countdown|playing|ended
    ticketId: null,
    room: null,                // Colyseus.Room
    stateRef: null,            // colyseus state
    queueStartTs: 0,
    myLoadout: { attackKey: null, defenseKey: null, defenseIcon: null }
  };

  const BLAPP = global.BLGAME_APP = (global.BLGAME_APP || {});

  // ===== Utils / Logs =====
  const $ = (sel, root = document) => root.querySelector(sel);
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));
  const LOG  = (...a) => console.log("[BLGAME]", ...a);
  const WARN = (...a) => console.warn("[BLGAME]", ...a);
  const ERR  = (...a) => console.error("[BLGAME]", ...a);

  // ===== Viewport vars =====
  function updateViewportVars() {
    const vw = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    const vh = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    document.documentElement.style.setProperty("--vwpx", vw + "px");
    document.documentElement.style.setProperty("--vhpx", vh + "px");
  }
  ["resize","orientationchange","visibilitychange"].forEach(ev => window.addEventListener(ev, updateViewportVars));

  // ===== Cria portal + move root =====
  function ensurePortalAndMount(root) {
    let portal = document.getElementById("blgame-fullmount");
    if (!portal) {
      portal = document.createElement("div");
      portal.id = "blgame-fullmount";
      document.body.appendChild(portal);
      LOG("portal criado e anexado ao <body>");
    }
    if (root && root.parentNode !== portal) {
      portal.appendChild(root);
      LOG("root movido para dentro do portal");
    }
    document.body.classList.add("blgame-full");
    updateViewportVars();
    return portal;
  }

  // ===== Loader de scripts (ordem garantida) =====
  function loadScript(src, id){
    return new Promise((resolve, reject)=>{
      if (id && document.getElementById(id)) { setTimeout(resolve, 0); return; }
      const s = document.createElement("script");
      s.src = src;
      if (id) s.id = id;
      s.async = false; s.defer = false;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error("Falha ao carregar: " + src));
      document.head.appendChild(s);
    });
  }

  // ===== Garantir pilha THREE (local -> fallback CDN) =====
  async function ensureThreeStack() {
    const base = (BLGAME.vendorThree || (BLGAME.assets + "vendor/three/"));
    async function tryLocal() {
      await loadScript(base + "three.min.js", "bl-three");
      await loadScript(base + "GLTFLoader.js", "bl-gltf");
      await loadScript(base + "SkeletonUtils.js", "bl-skel");
    }
    try {
      if (!global.THREE) { LOG("[3D] carregando THREE local…"); await tryLocal(); }
      if (!global.THREE) throw new Error("THREE ausente após local");
      if (!THREE.GLTFLoader) throw new Error("GLTFLoader ausente após local");
      if (!THREE.SkeletonUtils) throw new Error("SkeletonUtils ausente após local");
      LOG("[3D] stack local ok");
    } catch (e) {
      WARN("[3D] local falhou, usando fallback CDN", e.message);
      await loadScript("https://unpkg.com/three@0.161.0/build/three.min.js", "bl-fb-three");
      await loadScript("https://unpkg.com/three@0.161.0/examples/js/loaders/GLTFLoader.js", "bl-fb-gltf");
      await loadScript("https://unpkg.com/three@0.161.0/examples/js/utils/SkeletonUtils.js", "bl-fb-skel");
      if (!global.THREE || !THREE.GLTFLoader || !THREE.SkeletonUtils) {
        throw new Error("THREE não ficou disponível nem no fallback.");
      }
      LOG("[3D] stack via CDN ok");
    }
    LOG("[3D] REV:", THREE.REVISION);
  }

  // ===== Constantes do “mundo” =====
  const CONSTS = {
    FIELD_WIDTH: 48,
    FIELD_HEIGHT: 28,
    BALL_RADIUS: 0.4,
    PLAYER_RADIUS: 0.7,
    DEF_MAGNET_RADIUS: 3.2,
    // Novo: relação de tamanho jogador/bola (altura ≈ valor × diâmetro da bola)
    PLAYER_TO_BALL_RATIO: 4.0
  };

  // ===== Helpers simples =====
  function setText(el, txt) { if (el) el.textContent = txt; }
  function mmss(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60).toString().padStart(2, "0");
    const ss = (s % 60).toString().padStart(2, "0");
    return `${m}:${ss}`;
  }

  // ===== API REST =====
  async function api(path, opts = {}) {
    const url = BLGAME.rest + path.replace(/^\//, "");
    const base = {
      credentials: "include",
      headers: Object.assign(
        { "X-WP-Nonce": BLGAME.restNonce },
        (opts.headers || {}),
        opts.body ? { "Content-Type": "application/json" } : {}
      ),
      method: opts.method || "GET",
      body: opts.body || undefined
    };
    const res = await fetch(url, base);
    let json = null;
    try { json = await res.json(); } catch (e) { /* vazio */ }
    if (!res.ok) WARN("API error", path, res.status, json);
    return json || { ok: false, httpStatus: res.status };
  }

  // ===== Builder de markup (fallback se .blgame-root não existir) =====
  function buildRootMarkup() {
    const root = document.createElement("div");
    root.className = "blgame-root";
    root.innerHTML = `
      <div class="blgame-canvas-wrap">
        <div id="blgame-3d" style="position:absolute; inset:0;"></div>
        <canvas class="blgame-canvas"></canvas>
      </div>

      <div class="blgame-overlay blgame-overlay--center" data-phase="idle">
        <div class="blgame-title">Pronto pra jogar?</div>
        <button id="blgame-btn-play" class="blgame-btn blgame-btn--primary blgame-btn--big">JOGAR</button>
        <div class="blgame-note">Use WASD para mover • J para Ataque • K para Defesa</div>
      </div>

      <div class="blgame-overlay blgame-overlay--center blgame-hidden" data-phase="queue">
        <div class="blgame-spinner"></div>
        <div class="blgame-title">Pareando… <span id="blgame-queue-timer">00:00</span></div>
        <button id="blgame-btn-cancel" class="blgame-btn blgame-btn--light">Cancelar</button>
      </div>

      <div class="blgame-overlay blgame-overlay--center blgame-hidden" data-phase="countdown">
        <div id="blgame-countdown-num" class="blgame-countdown">3</div>
      </div>

      <div class="blgame-overlay blgame-overlay--top blgame-hidden" data-phase="hud">
        <div class="blgame-hud">
          <span class="blgame-score"><span id="blgame-score-a">0</span> — <span id="blgame-score-b">0</span></span>
          <span class="blgame-timer" id="blgame-match-timer">00:00</span>
          <img id="blgame-special-icon" alt="" style="width:18px;height:18px;opacity:.85" />
        </div>
      </div>

      <div class="blgame-overlay blgame-overlay--bottom blgame-hidden" data-phase="controls-desktop">
        <div class="blgame-controls"><b>WASD</b> mover • <b>J</b> Ataque • <b>K</b> Defesa</div>
      </div>

      <div class="blgame-overlay blgame-overlay--bottom blgame-hidden" data-phase="controls-mobile">
        <div class="blgame-joystick" id="blgame-joy"><div class="knob"></div></div>
        <div class="blgame-buttons">
          <button id="blgame-btn-attack" class="blgame-btn blgame-btn--primary blgame-btn--big">ATAQUE</button>
          <button id="blgame-btn-defense" class="blgame-btn blgame-btn--light blgame-btn--big">DEFESA</button>
        </div>
      </div>

      <div class="blgame-overlay blgame-overlay--center blgame-hidden" data-phase="ended">
        <div class="blgame-title" id="blgame-ended-title">Partida encerrada</div>
        <div style="display:flex; gap:10px; justify-content:center;">
          <button id="blgame-btn-requeue" class="blgame-btn blgame-btn--primary blgame-btn--big">Jogar de novo</button>
          <button id="blgame-btn-exit" class="blgame-btn blgame-btn--light blgame-btn--big">Sair</button>
        </div>
      </div>

      <div id="blgame-orientation" class="blgame-orientation blgame-hidden">Gire o dispositivo para paisagem para jogar melhor.</div>
    `;
    document.body.appendChild(root);
    LOG("markup de fallback criado (.blgame-root)");
    return root;
  }

  // ===== Exports =====
  BLAPP.utils  = { $, delay, LOG, WARN, ERR, setText, mmss };
  BLAPP.dom    = { updateViewportVars, ensurePortalAndMount, buildRootMarkup };
  BLAPP.loader = { loadScript, ensureThreeStack };
  BLAPP.consts = CONSTS;
  BLAPP.api    = api;

})(window);
