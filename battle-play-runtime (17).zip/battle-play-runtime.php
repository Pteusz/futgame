<?php
/**
 * Plugin Name: Battle Play – Game Runtime
 * Description: Runtime do jogo (shortcode [soque_play]): botão Jogar → fila → match → conexão WS.
 * Version: 1.2.5
 * Author: Mateus + ChatGPT
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

// BUMP de versão para bust de cache dos scripts
define('BLGAME_VERSION', '1.2.5');

define('BLGAME_DIR', plugin_dir_path(__FILE__));
define('BLGAME_URL', plugin_dir_url(__FILE__));

require_once BLGAME_DIR . 'inc/class-rest.php';
require_once BLGAME_DIR . 'inc/class-shortcode.php';
require_once BLGAME_DIR . 'inc/class-db-bridge.php';

add_action('plugins_loaded', function () {
  // REST (proxy p/ soque-api + leitura do set)
  (new BLGAME_REST())->register();
});
