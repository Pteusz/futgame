<?php
if (!defined('ABSPATH')) exit;

/**
 * REST do runtime:
 * - GET  /blgame/v1/set           → retorna set completo (ícone + key) e validação mínima
 * - POST /blgame/v1/queue/join    → proxy p/ https://soque.lovlab.com.br/api/queue/join
 * - GET  /blgame/v1/queue/status  → proxy p/ https://soque.lovlab.com.br/api/queue/status/:ticketId
 */
class BLGAME_REST {
  const NS = 'blgame/v1';

  // Ajuste aqui se o host do game mudar
  const SOQUE_API_BASE = 'https://soque.lovlab.com.br/api';

  public function register() {
    add_action('rest_api_init', function () {
      register_rest_route(self::NS, '/set', [
        'methods'  => 'GET',
        'callback' => [$this, 'get_set'],
        'permission_callback' => function () { return is_user_logged_in(); }
      ]);

      register_rest_route(self::NS, '/queue/join', [
        'methods'  => 'POST',
        'callback' => [$this, 'queue_join'],
        'permission_callback' => function () { return is_user_logged_in(); }
      ]);

      register_rest_route(self::NS, '/queue/status', [
        'methods'  => 'GET',
        'callback' => [$this, 'queue_status'],
        'permission_callback' => '__return_true'
      ]);
    });
  }

  public function get_set(\WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $db = new BLGAME_DB_Bridge();

    $full = $db->get_user_set_full($user_id);
    $min  = $db->get_user_set_min($user_id);

    if (!$min['attackVersionId'] || !$min['defenseVersionId']) {
      return new \WP_REST_Response(['ok'=>false, 'error'=>'set_incompleto'], 200);
    }

    return [
      'ok'  => true,
      'set' => [
        'ataque'  => $full['ataque'],
        'defesa'  => $full['defesa'],
        'passiva' => $full['passiva'],
        'min'     => $min,
      ]
    ];
  }

  public function queue_join(\WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $db = new BLGAME_DB_Bridge();
    $set = $db->get_user_set_min($user_id);

    if (!$set['attackVersionId'] || !$set['defenseVersionId']) {
      return new \WP_REST_Response(['ok'=>false,'error'=>'set_incompleto'], 200);
    }

    $body = [
      'userId'  => (string)$user_id,
      'snapshot'=> [
        'attackVersionId'  => $set['attackVersionId'],
        'defenseVersionId' => $set['defenseVersionId'],
        'passiveVersionId' => $set['passiveVersionId'],
      ]
    ];

    $resp = wp_remote_post(self::SOQUE_API('/queue/join'), [
      'headers' => ['Content-Type'=>'application/json'],
      'body'    => wp_json_encode($body),
      'timeout' => 10,
    ]);

    if (is_wp_error($resp)) {
      return new \WP_REST_Response(['ok'=>false,'error'=>'queue_join_failed'], 500);
    }
    $code = wp_remote_retrieve_response_code($resp);
    $json = json_decode(wp_remote_retrieve_body($resp), true);
    if ($code >= 200 && $code < 300 && !empty($json['ticketId'])) {
      return ['ok'=>true, 'ticketId'=>$json['ticketId']];
    }
    return new \WP_REST_Response(['ok'=>false,'error'=>'queue_join_bad_response','raw'=>$json], 500);
  }

  public function queue_status(\WP_REST_Request $req) {
    $ticketId = sanitize_text_field($req->get_param('ticketId') ?: '');
    if (!$ticketId) return new \WP_REST_Response(['ok'=>false,'error'=>'ticket_required'], 400);

    $resp = wp_remote_get(self::SOQUE_API('/queue/status/'.rawurlencode($ticketId)), [
      'timeout' => 10,
    ]);
    if (is_wp_error($resp)) {
      return new \WP_REST_Response(['ok'=>false,'error'=>'queue_status_failed'], 500);
    }
    $code = wp_remote_retrieve_response_code($resp);
    $json = json_decode(wp_remote_retrieve_body($resp), true);
    if ($code >= 200 && $code < 300) {
      return ['ok'=>true, 'data'=>$json];
    }
    return new \WP_REST_Response(['ok'=>false,'error'=>'queue_status_bad_response','raw'=>$json], 500);
  }

  private static function SOQUE_API($path) {
    return rtrim(self::SOQUE_API_BASE, '/') . $path;
  }
}
