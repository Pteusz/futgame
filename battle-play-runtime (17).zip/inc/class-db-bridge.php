<?php
if (!defined('ABSPATH')) exit;

/**
 * Bridge de leitura do set do jogador a partir das tabelas do plugin "Battle Lobby – Set de Artefatos".
 * - get_user_set_min(): mantém compat p/ snapshot (ids de versão)
 * - get_user_set_full(): inclui nome + ícone do artefato por slot e chave "slug" (ex.: buraco_negro)
 */
class BLGAME_DB_Bridge {
  private $t_conjunto;
  private $t_artefatos;

  public function __construct() {
    global $wpdb;
    $this->t_conjunto  = $wpdb->prefix . 'bl_jogador_conjunto';
    $this->t_artefatos = $wpdb->prefix . 'bl_artefatos';
  }

  /**
   * Retorna apenas IDs (compat com lógica de fila)
   * ['attackVersionId'=>int|null, 'defenseVersionId'=>int|null, 'passiveVersionId'=>int|null]
   */
  public function get_user_set_min($user_id) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT slot, id_versao_artefato AS ver FROM {$this->t_conjunto} WHERE id_jogador = %d",
      $user_id
    ), ARRAY_A);

    $out = ['attackVersionId'=>null, 'defenseVersionId'=>null, 'passiveVersionId'=>null];
    foreach ($rows as $r) {
      switch ($r['slot']) {
        case 'ataque':  $out['attackVersionId']  = intval($r['ver']); break;
        case 'defesa':  $out['defenseVersionId'] = intval($r['ver']); break;
        case 'passiva': $out['passiveVersionId'] = intval($r['ver']); break;
      }
    }
    return $out;
  }

  /**
   * Retorna estrutura completa para o front:
   * [
   *   'ataque' => ['id_artefato'=>..,'id_versao'=>..,'nome'=>..,'icone_url'=>..,'key'=>..],
   *   'defesa' => [...],
   *   'passiva'=> [...]
   * ]
   */
  public function get_user_set_full($user_id) {
    global $wpdb;

    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT c.slot, c.id_versao_artefato AS id_versao, a.id_artefato, a.nome, a.icone_url
         FROM {$this->t_conjunto} c
         JOIN {$this->t_artefatos} a ON a.id_artefato = c.id_artefato
        WHERE c.id_jogador = %d",
      $user_id
    ), ARRAY_A);

    $out = ['ataque'=>null,'defesa'=>null,'passiva'=>null];

    foreach ($rows as $r) {
      $slot = $r['slot'];
      $nome = $r['nome'];

      // key padronizada (ex: "Buraco negro" → "buraco_negro")
      $key = str_replace('-', '_', sanitize_title($nome));

      $out[$slot] = [
        'id_artefato' => intval($r['id_artefato']),
        'id_versao'   => intval($r['id_versao']),
        'nome'        => $nome,
        'icone_url'   => $r['icone_url'],
        'key'         => $key,
      ];
    }

    return $out;
  }
}
