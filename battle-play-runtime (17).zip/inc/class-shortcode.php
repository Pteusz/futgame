<?php
if (!defined('ABSPATH')) exit;

class BLGAME_Shortcode_Play {
  public function __construct() {
    add_shortcode('soque_play', [$this, 'render']);
  }

  public function render($atts = []) {
    // CSS
    wp_enqueue_style('blgame-style', BLGAME_URL . 'assets/style.css', [], BLGAME_VERSION);

    // Colyseus
    wp_register_script('colyseus-js', 'https://unpkg.com/colyseus.js@0.15.16/dist/colyseus.js', [], null, true);
    wp_enqueue_script('colyseus-js');

    // === THREE LOCAL (evita bloqueios/AdBlock) ===
    $three_base = BLGAME_URL . 'assets/vendor/three/';
    wp_register_script('three-js',   $three_base . 'three.min.js', [], BLGAME_VERSION, true);
    wp_register_script('three-gltf', $three_base . 'GLTFLoader.js', ['three-js'], BLGAME_VERSION, true);
    wp_register_script('three-skel', $three_base . 'SkeletonUtils.js', ['three-js'], BLGAME_VERSION, true);

    if (function_exists('wp_script_add_data')) {
      foreach (['three-js','three-gltf','three-skel','colyseus-js'] as $h) {
        wp_script_add_data($h, 'defer', false);
        wp_script_add_data($h, 'async', false);
      }
    }
    wp_enqueue_script('three-js');
    wp_enqueue_script('three-gltf');
    wp_enqueue_script('three-skel');

    // Joystick
    wp_enqueue_script('blgame-joystick', BLGAME_URL . 'assets/joystick.js', [], BLGAME_VERSION, true);

    // ===== Core primeiro (expõe BLGAME) =====
    wp_enqueue_script('blgame-core', BLGAME_URL . 'assets/js/blgame-core.js', [], BLGAME_VERSION, true);

    // Dados globais p/ os módulos
    wp_localize_script('blgame-core', 'BLGAME', [
      'rest'           => esc_url_raw(rest_url('blgame/v1/')),
      'wsUrl'          => 'wss://soque.lovlab.com.br',
      'assets'         => BLGAME_URL . 'assets/',
      'models'         => BLGAME_URL . 'assets/models/',
      'vendorThree'    => $three_base,
      'isUserLoggedIn' => is_user_logged_in(),
      'restNonce'      => wp_create_nonce('wp_rest'),
    ]);

    // Input/FX depende do core + joystick
    wp_enqueue_script('blgame-input-fx', BLGAME_URL . 'assets/js/blgame-input-fx.js', ['blgame-core','blgame-joystick'], BLGAME_VERSION, true);

    // 3D depende do core + three stack
    wp_enqueue_script('blgame-3d', BLGAME_URL . 'assets/js/blgame-3d.js', ['blgame-core','three-js','three-gltf','three-skel'], BLGAME_VERSION, true);

    // App final depende de tudo + colyseus
    wp_enqueue_script('blgame-app', BLGAME_URL . 'assets/js/blgame-app.js', ['blgame-core','blgame-input-fx','blgame-3d','colyseus-js'], BLGAME_VERSION, true);

    // Blindagem: se algum handle antigo existir (ex.: render3d), remova
    if (function_exists('wp_dequeue_script')) {
      foreach (['render3d','bl-render3d','app-old'] as $legacy) {
        wp_dequeue_script($legacy);
        wp_deregister_script($legacy);
      }
    }

    if (function_exists('wp_script_add_data')) {
      foreach (['blgame-core','blgame-input-fx','blgame-3d','blgame-app'] as $h) {
        wp_script_add_data($h, 'defer', false);
        wp_script_add_data($h, 'async', false);
      }
    }

    // Root do jogo
    ob_start(); ?>
      <div class="blgame-root">
        <div class="blgame-canvas-wrap">
          <div id="blgame-3d" style="position:absolute; inset:0;"></div>
          <canvas class="blgame-canvas"></canvas>
        </div>

        <div class="blgame-overlay blgame-overlay--center" data-phase="idle">
          <div class="blgame-title">Pronto pra jogar?</div>
          <button id="blgame-btn-play" class="blgame-btn blgame-btn--primary blgame-btn--big">JOGAR</button>
          <div class="blgame-note">Use WASD • J ataque • K defesa</div>
        </div>

        <div class="blgame-overlay blgame-overlay--center blgame-hidden" data-phase="queue">
          <div class="blgame-spinner"></div>
          <div class="blgame-title">Pareando… <span id="blgame-queue-timer">00:00</span></div>
          <button id="blgame-btn-cancel" class="blgame-btn blgame-btn--light">Cancelar</button>
        </div>

        <div class="blgame-overlay blgame-overlay--center blgame-hidden" data-phase="countdown">
          <div id="blgame-countdown-num" class="blgame-countdown">3</div>
        </div>

        <div class="blgame-overlay blgame-overlay--top blgame-hidden" data-phase="hud">
          <div class="blgame-hud">
            <span class="blgame-score"><span id="blgame-score-a">0</span> — <span id="blgame-score-b">0</span></span>
            <span class="blgame-timer" id="blgame-match-timer">00:00</span>
            <img id="blgame-special-icon" alt="" style="width:18px;height:18px;opacity:.85" />
          </div>
        </div>

        <div class="blgame-overlay blgame-overlay--bottom blgame-hidden" data-phase="controls-desktop">
          <div class="blgame-controls"><b>WASD</b> mover • <b>J</b> Ataque • <b>K</b> Defesa</div>
        </div>

        <div class="blgame-overlay blgame-overlay--bottom blgame-hidden" data-phase="controls-mobile">
          <div class="blgame-joystick" id="blgame-joy"><div class="knob"></div></div>
          <div class="blgame-buttons">
            <button id="blgame-btn-attack" class="blgame-btn blgame-btn--primary blgame-btn--big">ATAQUE</button>
            <button id="blgame-btn-defense" class="blgame-btn blgame-btn--light blgame-btn--big">DEFESA</button>
          </div>
        </div>

        <div class="blgame-overlay blgame-overlay--center blgame-hidden" data-phase="ended">
          <div class="blgame-title" id="blgame-ended-title">Partida encerrada</div>
          <div style="display:flex; gap:10px; justify-content:center;">
            <button id="blgame-btn-requeue" class="blgame-btn blgame-btn--primary blgame-btn--big">Jogar de novo</button>
            <button id="blgame-btn-exit" class="blgame-btn blgame-btn--light blgame-btn--big">Sair</button>
          </div>
        </div>

        <div id="blgame-orientation" class="blgame-orientation blgame-hidden">Gire o dispositivo para paisagem para jogar melhor.</div>
      </div>
    <?php
    return ob_get_clean();
  }
}
new BLGAME_Shortcode_Play();
